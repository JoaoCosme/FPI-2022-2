# Todo

- [x] Histograma
- [x] Brilho
  - [x] Operação
  - [x] Aumentar/Reduzir
- [x] Contraste
  - [x] Operação
  - [x] Aumentar/Reduzir
- [x] Negativo
- [x] Equalização
- [ ] Histogram Matching
  - [ ] Grey
  - [ ] Color
- [x] Zoom Out
- [x] Zoom In
- [x] Rotate
- [x] Convolução
- [ ] Bug de step anterior
- [ ] Relatorio
